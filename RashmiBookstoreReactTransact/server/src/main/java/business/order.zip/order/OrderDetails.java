package business.order;

public class OrderDetails {

    // NOTE: THIS CLASS PROVIDED NEXT PROJECT
}
